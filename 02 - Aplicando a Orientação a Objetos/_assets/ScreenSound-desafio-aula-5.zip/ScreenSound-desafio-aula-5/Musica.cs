class Musica
{
    public string nome;
    public DateTime dataLancamento;
    public int duracao;
    public bool disponivel;
}